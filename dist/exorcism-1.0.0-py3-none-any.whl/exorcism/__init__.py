from .main import (
    system,
    color,
    animate,
    frame,
    center,
    table,
    progress,
    convert,
)

__version__ = '1.0.0'
__author__ = 'notkiwy'
